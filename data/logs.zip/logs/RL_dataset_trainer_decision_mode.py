


# loud csv file for RL dataset training
import os
#from turtle import pd
import pandas as pd 
import re

TILE_SIZE = 32
GRID_WIDTH = 20
GRID_HEIGHT = 15
SCREEN_WIDTH = TILE_SIZE * GRID_WIDTH
SCREEN_HEIGHT = TILE_SIZE * GRID_HEIGHT


# If True, build the dataset from 'decision' log rows (recommended, aligned with decision-time state).
# If False, use the older snapshot reconstruction from move/breeding rows (may have mismatch).
USE_DECISION_LOGS = True

_DECISION_RE = re.compile(r"(?:^|\s)adj_male=(\d)\s+adj_empty=(\d)(?:\s|$)")

def parse_decision_details(details: str):
    """Extract (adj_male, adj_empty) from a 'decision' details string like 'adj_male=1 adj_empty=0'."""
    if not isinstance(details, str):
        return None
    m = _DECISION_RE.search(details.strip())
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))

def debug_suspicious_move(turn_df, female_row):
    # build occupied_positions
    occupied_positions = set(turn_df["location"])
    # build pos_to_row mapping
    pos_to_row = {row["location"]: row for _, row in turn_df.iterrows()}
    # compute N/S/W/E positions
    x, y = female_row["location"]
    adjacent_positions = [
    (x, y - 1),  # North
    (x, y + 1),  # South
    (x - 1, y),  # West
    (x + 1, y)   # East
    ]

    # print female info
    print(f"Female bunny at location {female_row['location']}") 
    # for each neighbor position:  
    for pos in adjacent_positions:
        # print if occupied? if yes print bunny info
        if pos in occupied_positions:
            neighbor_row = pos_to_row[pos]
            # print neighbor info of turn_df,bunny_id, age, sex, mutant,event_type,location
            print(f"  Occupied by bunny {neighbor_row['bunny_id']} at location {neighbor_row['location']} with age {neighbor_row['age']}, sex {neighbor_row['sex']}, mutant {neighbor_row['mutant']}, event_type {neighbor_row['event_type']}")
            # print(f"  Occupied by bunny {neighbor_row['bunny_id']} at location {neighbor_row['location']}")
        else:
            # print if empty if not out of bounds
            if 0 <= pos[0] < GRID_WIDTH and 0 <= pos[1] < GRID_HEIGHT:
                print(f"  Empty tile at location {pos}")
            else:
                print(f"  Out of bounds at location {pos}")
    
    # print computed features
    adjacent_adult_male_bunnies = turn_df[(turn_df["location"].isin(adjacent_positions)) & (turn_df["sex"] == "M") & (turn_df["age"] >= 2) & (turn_df["mutant"] == False)]
    adjacent_empty_tile = any( 
        pos not in occupied_positions for pos in adjacent_positions
    )

    print(f"Adjacent adult male bunnies: {adjacent_adult_male_bunnies.shape[0]}")
    print(f"Adjacent empty tile: {adjacent_empty_tile}")

    X = [
        female_row["age"],
        int(female_row["mutant"]),
        int(not adjacent_adult_male_bunnies.empty),
        int(adjacent_empty_tile)
    ]

    #y = 1 if female_row["event_type"] == "breeding" else 0 if female_row["event_type"] == "move" else -1  # -1 for no action
    y = 1 if female_row["event_type"] == "breeding" else 0
    print(f"Features: {X}, Label: {y}")





#load file
csv_file = "log_test.csv"  # Replace with your actual file path
df = pd.read_csv(csv_file)

# Keep original row order for within-turn / within-agent sequencing.
df = df.reset_index(drop=True)
df["_row"] = df.index

# Sort primarily by turn, then by file order.
df = df.sort_values(["turn", "_row"])

# Process location column to extract x and y coordinates (still useful for debugging/analysis)
df["location"] = df["location"].astype(str).str.strip("()")
df[["x", "y"]] = df["location"].str.split(",", expand=True)
df["x"] = df["x"].astype(int)
df["y"] = df["y"].astype(int)
df["location"] = list(zip(df["x"], df["y"]))

suspicious_count = 0
X_data = []
y_data = []

if USE_DECISION_LOGS:
    # Decision-aligned dataset:
    # For each bunny_id, pair a 'decision' row with the next move/breeding action row for the same bunny.
    # This avoids the end-of-turn snapshot mismatch.
    for bunny_id, g in df.groupby("bunny_id", sort=False):
        g = g.sort_values(["turn", "_row"])
        pending = None  # (turn, features)

        for _, row in g.iterrows():
            et = row["event_type"]

            if et == "decision":
                # Filter to adult, non-mutant females (your 'A' choice)
                if row["sex"] != "F" or row["age"] < 2 or bool(row["mutant"]) is True:
                    pending = None
                    continue
                

                parsed = parse_decision_details(row.get("details", ""))
                if parsed is None:
                    pending = None
                    continue

                adj_male, adj_empty = parsed

                # Feature vector (keep it simple and consistent)
                X = [
                    int(adj_male),
                    int(adj_empty),
                ]
                pending = (int(row["turn"]), X)
                continue

            # If we have a pending decision, the next action by this bunny is the label.
            if pending is not None and et in ("move", "breeding"):
                decision_turn, X = pending

                # Optional: require action to be in the same turn as the decision
                # (recommended if your FSM logs decision right before acting)
                # if int(row["turn"]) != decision_turn:
                #     # If turns don't match, drop it to avoid pairing with a later unrelated action.
                #     pending = None
                #     continue

                # allow next action even if turn differs
                # (optional) you can keep a max gap like <= 1 if you want
                # y = 1 if et == "breeding" else 0
                # X_data.append(X)
                # y_data.append(y)
                # pending = None

                if int(row["turn"]) - decision_turn > 1:
                    pending = None
                    continue


                

                y = 1 if et == "breeding" else 0
                X_data.append(X)
                y_data.append(y)
                pending = None
else:
    # Older snapshot-based dataset (kept for comparison / fallback)
    for turn in sorted(df["turn"].unique()):
        turn_df = df[df["turn"] == turn]

        occupied_positions = set(turn_df["location"])

        female_df = turn_df[(turn_df["sex"] == "F") & (turn_df["age"] >= 2) & (turn_df["mutant"] == False)]

        for _, female_row in female_df.iterrows():
            if female_row["event_type"] not in ["breeding", "move"]:
                continue

            x, y = female_row["location"]
            adjacent_positions = [
                (x, y - 1),  # North
                (x, y + 1),  # South
                (x - 1, y),  # West
                (x + 1, y)   # East
            ]
            adjacent_positions = [(nx, ny) for (nx, ny) in adjacent_positions if 0 <= nx < GRID_WIDTH and 0 <= ny < GRID_HEIGHT]

            adjacent_adult_male_bunnies = turn_df[(turn_df["location"].isin(adjacent_positions)) & (turn_df["sex"] == "M") & (turn_df["age"] >= 2) & (turn_df["mutant"] == False)]
            adjacent_empty_tile = any(pos not in occupied_positions for pos in adjacent_positions)

            X = [
                int(adjacent_adult_male_bunnies.shape[0] > 0),
                int(adjacent_empty_tile)
            ]
            y = 1 if female_row["event_type"] == "breeding" else 0
            X_data.append(X)
            y_data.append(y)

            if (
                int(adjacent_adult_male_bunnies.shape[0] > 0) == 1
                and int(adjacent_empty_tile) == 1
                and female_row["event_type"] == "move"
            ):
                suspicious_count += 1

print("Suspicious cases:", suspicious_count)
print("Total samples:", len(y_data))
print("Breeding (1):", sum(y_data))
print("Move (0):", len(y_data) - sum(y_data))
 
import pandas as pd

df = pd.read_csv("log_test.csv")
print(df["event_type"].value_counts().head(20))
print("decision rows:", (df["event_type"] == "decision").sum())

d = df[df["event_type"] == "decision"]["details"].head(10).tolist()
print(d)
